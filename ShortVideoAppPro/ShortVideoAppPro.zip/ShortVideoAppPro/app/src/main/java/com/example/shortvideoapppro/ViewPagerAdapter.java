package com.example.shortvideoapppro;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextPaint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;


import java.util.List;

public class ViewPagerAdapter extends RecyclerView.Adapter<ViewPagerAdapter.VideoViewHolder> {

    private static final String TAG = "ViewPagerAdapter";
    private List<VideoResponse> videoInfos;
    private Context mContext;
    private ListItemClickListener mOnClickListener;

    public ViewPagerAdapter(Context context){
        this.mContext = context;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.video_item, viewGroup, false);
        VideoViewHolder vh = new VideoViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull final VideoViewHolder holder, final int position) {
        Log.d(TAG, String.valueOf(position));

        String CoverPath = videoInfos.get(position).feedurl;
        String HeadPhotoPath = videoInfos.get(position).avatar;

        Glide.with(mContext).asBitmap()
                .load(CoverPath)
                .into(new SimpleTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition){
                        int width = resource.getWidth();
                        int height = resource.getHeight();
                        Log.d(TAG,"width:"+width);
                        Log.d(TAG,"height:"+height);
                        if(height > width){
                            holder.ImageCover.setScaleType(ImageView.ScaleType.FIT_XY);
                        }
                        else{
                            holder.ImageCover.setScaleType(ImageView.ScaleType.CENTER);
                        }
                    }
                });

        Glide.with(mContext).setDefaultRequestOptions(new RequestOptions()
                .frame(1000000).fitCenter().error(R.mipmap.failure).placeholder(R.mipmap.loading))
                .load(CoverPath)
                .into(holder.ImageCover);

        holder.PlayPhoto.setImageResource(R.mipmap.play);

        holder.Nickname.setText("@" + videoInfos.get(position).nickname);
        TextPaint tp = holder.Nickname.getPaint();
        tp.setFakeBoldText(true);

        holder.Description.setText(videoInfos.get(position).description);

        if(mOnClickListener != null){
            holder.ImageCover.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mOnClickListener.onListItemClick(position);
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return videoInfos == null ? 0:videoInfos.size();
    }

    public static class VideoViewHolder extends RecyclerView.ViewHolder{
        public ImageView ImageCover;
        public TextView Nickname;
        public TextView Description;
        public ImageView PlayPhoto;

        public VideoViewHolder(View videoView){
            super(videoView);
            ImageCover = videoView.findViewById(R.id.ImageCover);
            Description = videoView.findViewById(R.id.Description);
            Nickname = videoView.findViewById(R.id.Nickname);
            PlayPhoto = videoView.findViewById(R.id.PlayPhoto);
        }

    }

    public void setData(List<VideoResponse> responses){
        videoInfos = responses;
        Log.d(TAG,videoInfos.toString());
    }

    public interface ListItemClickListener {
        void onListItemClick(int clickedItemIndex);
    }

    public void setOnItemClickListener(ListItemClickListener listItemClickListener){
        this.mOnClickListener = listItemClickListener;
    }
}
