package com.example.shortvideoapppro;

public class VideoResponse {

    public String feedurl;
    public String nickname;
    public String description;
    public String avatar;
    public int likecount;

    @Override
    public String toString() {
        return "VideoInfo{" +
                "feedurl=" + feedurl +
                ", nickname='" + nickname  +
                ", description=" + description +
                ", likecount=" + likecount +
                ", avatar=" + avatar +
                '}';
    }

}
